using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectHealth : MonoBehaviour
    //reusable variables
{
    public float health = 100;
    public float maxhealth = 100;
    public bool doeshealthdecay = false;
    public float decayamount = 2;
   
}
